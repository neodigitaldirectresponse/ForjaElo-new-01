
// popup.js — ForjaElo 6.7 · SSA 8.7 — PRO (rebuild)
// Atenção: este arquivo substitui o popup.js anterior com correções e os recursos pedidos.

(() => {
  'use strict';

  // Helpers
  const $  = (q, root=document) => root.querySelector(q);
  const $$ = (q, root=document) => Array.from(root.querySelectorAll(q));
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  // ---------- Trilhas A–N (campos e builders) ----------
  // Cada build(v) retorna um array de prompts prontos.
  const TRILHAS = [
    {
      id: "A",
      nome: "A) Dia Completo (abrange todos os elos)",
      fields: [
        {key:"agenda", label:"Agenda do dia + contexto"},
        {key:"prioridades", label:"Prioridades (Topo)"},
        {key:"ruidos", label:"Fontes de distração"},
        {key:"tarefas_criticas", label:"Tarefas críticas (T2)"},
        {key:"preferencias", label:"Preferências/Condições (Box)"},
        {key:"ambiente", label:"Ambiente (Refúgio/ritual)"},
        {key:"escopo", label:"Escopo do principal"},
        {key:"log", label:"Log rápido"},
        {key:"resultados", label:"Resultados do dia"}
      ],
      build: (v) => [
        `SSA, sintetize meu “porquê de hoje” (Chama 5) em 1 frase e liste 3 sinais visíveis de progresso. Base: ‹${v.agenda||""}›.`,
        `SSA, gere meu Top-3 neutro: T1 Propósito (Chama), T2 Resultado (Talentos/Potência), T3 Elo do dia (calendário). Base: ‹${v.prioridades||""}›.`,
        `SSA, defina limites (Central): padrão neutro, avisos de “limitar exposição”, janelas de e-mail/mensagens e no-go list. Base: ‹${v.ruidos||""}›.`,
        `SSA, formate um checklist Potência (5–7 itens) com timers (25/5) para executar o T2; inclua checkpoints, travas e critério de “pronto”. Base: ‹${v.tarefas_criticas||""}›.`,
        `SSA, proponha 1 microtreino Box (≤10 min) para energia mental/física antes do bloco principal; inclua como medir (0–5). Base: ‹${v.preferencias||""}›.`,
        `SSA, crie Elo do Refúgio: ritual de 3–5 min (desligar, respirar, anotar 1 insight) com gatilho e horário. Base: ‹${v.ambiente||""}›.`,
        `SSA, desenhe Sprint10 (10 passos curtos) para fechar o principal do dia até as 20:00, com timers e travas objetivas. Base: ‹${v.escopo||""}›.`,
        `SSA, registre métrica leve do dia: esforço/energia/atrito/progresso (0–5) + 3 aprendizados. Base: ‹${v.log||""}›.`,
        `SSA, faça revisão EOD em 6 bullets (feito/pendente/atrito/aprendizados/agradecer/próximo foco) e gere o Top-3 neutro de amanhã. Base: ‹${v.resultados||""}›.`
      ]
    },
    {
      id: "B",
      nome: "B) Projeto · do zero ao envio (kickoff → envio 1)",
      fields: [
        {key:"briefing", label:"Briefing/Projeto"},
        {key:"escopo", label:"Escopo"},
        {key:"pipeline", label:"Pipeline"},
        {key:"stakeholders", label:"Stakeholders"},
        {key:"preferencias", label:"Preferências"},
        {key:"parcerias", label:"Parcerias"},
        {key:"agenda", label:"Agenda"},
        {key:"entrega_alvo", label:"Entrega-alvo"}
      ],
      build: (v) => [
        `SSA, com base no texto abaixo, crie: (1) objetivo em 1 frase; (2) 3 passos mínimos; (3) travas + Sprint10. Texto: ‹${v.briefing||""}›.`,
        `SSA, descreva o resultado esperado (T2 Resultado) em 1 frase e 3 critérios de excelência (Talentos). Base: ‹${v.escopo||""}›.`,
        `SSA, mapeie processos (Potência): checklist curto (5–7) com timers e checkpoints; inclua “pronto/feito”. Base: ‹${v.pipeline||""}›.`,
        `SSA, defina limites (Central) específicos do projeto: canais, horários, pontos de decisão; inclua aviso padrão de “limitar exposição”. Base: ‹${v.stakeholders||""}›.`,
        `SSA, proponha microtreino Box (≤10 min) para iniciar os blocos e reduzir atrito. Base: ‹${v.preferencias||""}›.`,
        `SSA, gere 2 roteiros Ide sem dados sensíveis: (a) convite frio de 3 linhas; (b) follow-up curto com CTA. Base: ‹${v.parcerias||""}›.`,
        `SSA, crie Elo do Refúgio para pausas estratégicas (3–5 min, passos claros). Base: ‹${v.agenda||""}›.`,
        `SSA, desenhe Sprint10 para o primeiro envio (D1) com estimativas rápidas, travas e “corte seguro”. Base: ‹${v.entrega_alvo||""}›.`
      ]
    },
    {
      id: "C",
      nome: "C) Semana Completa (planejamento → retrospectiva)",
      fields: [
        {key:"metas", label:"Metas"},
        {key:"calendario", label:"Calendário"},
        {key:"rotina", label:"Rotina"},
        {key:"tipo_trabalho", label:"Tipo de trabalho"},
        {key:"preferencias", label:"Preferências (Box)"},
        {key:"leads", label:"Lista de leads"},
        {key:"energia", label:"Energia"},
        {key:"backlog", label:"Backlog"},
        {key:"registros", label:"Registros"}
      ],
      build: (v) => [
        `SSA, consolide meu Propósito da semana (Chama) em 1 frase e 3 resultados-chave observáveis. Base: ‹${v.metas||""}›.`,
        `SSA, gere um Roadmap Potência (processos + timers) para 5 dias: blocos focais/delivery/revisão. Base: ‹${v.calendario||""}›.`,
        `SSA, estabeleça padrões Central: janelas de comunicação, regras de contexto profundo, e checklist “entrar/sair de foco”. Base: ‹${v.rotina||""}›.`,
        `SSA, defina critérios Talentos (excelência/QA) e template de empacotamento de entregas. Base: ‹${v.tipo_trabalho||""}›.`,
        `SSA, agende microtreinos Box (≤10 min) distribuídos na semana (força, mobilidade, respiração). Base: ‹${v.preferencias||""}›.`,
        `SSA, crie 3 roteiros Ide (contato inicial, nurture curto, fechamento com CTA) sem dados sensíveis. Base: ‹${v.leads||""}›.`,
        `SSA, janelas Refúgio (descanso/detox): horários, rituais e limites práticos. Base: ‹${v.energia||""}›.`,
        `SSA, Sprint10 semanal: 10 passos de execução com checkpoints por dia. Base: ‹${v.backlog||""}›.`,
        `SSA, retro semanal em 8 bullets (ganhos, perdas, atritos, riscos, oportunidades, aprendizados, descarte, foco seguinte). Base: ‹${v.registros||""}›.`
      ]
    },
    {
      id: "D",
      nome: "D) Funil de Parcerias (Ide + Resultado)",
      fields: [
        {key:"produto", label:"Produto/Serviço"},
        {key:"perfil", label:"Perfil do contato"},
        {key:"meta_contatos", label:"Meta de contatos"},
        {key:"etica", label:"Ética/Limites"},
        {key:"janela", label:"Janela disponível"}
      ],
      build: (v) => [
        `SSA, extraia proposta de valor em 1 frase e 3 provas de credibilidade. Base: ‹${v.produto||""}›.`,
        `SSA, crie 3 roteiros Ide sem dados sensíveis: DM curta, e-mail de 4 linhas e mensagem de follow-up (72h) — cada um com CTA. Base: ‹${v.perfil||""}›.`,
        `SSA, monte checklist Potência (5–7) com timers para disparo, registro, qualificação e revisão diária do funil (T2 Resultado). Base: ‹${v.meta_contatos||""}›.`,
        `SSA, defina travas Central: limites por dia, horário de outreach e regras de não-insistência. Base: ‹${v.etica||""}›.`,
        `SSA, Sprint10 para “primeiros 10 contatos” com checkpoints objetivos e “stop-loss” de tempo. Base: ‹${v.janela||""}›.`
      ]
    },
    {
      id: "E",
      nome: "E) Qualidade & Excelência (Talentos)",
      fields: [
        {key:"entrega", label:"Entrega"},
        {key:"workflow", label:"Workflow"},
        {key:"prazos", label:"Prazos"},
        {key:"escopo", label:"Escopo"}
      ],
      build: (v) => [
        `SSA, descreva “o que é excelente” em 1 frase e defina 3 critérios mensuráveis de QA. Base: ‹${v.entrega||""}›.`,
        `SSA, gere checklist Potência de QA (5–7) com timers por etapa (rascunho → revisão → empacote → envio). Base: ‹${v.workflow||""}›.`,
        `SSA, inclua travas para não-perfeccionismo (Central): limite de revisões e gatilho de envio. Base: ‹${v.prazos||""}›.`,
        `SSA, Sprint10 de empacotamento (10 passos curtos) para fechar hoje. Base: ‹${v.escopo||""}›.`
      ]
    },
    {
      id: "F",
      nome: "F) Foco Profundo (proteção + execução)",
      fields: [
        {key:"tarefa", label:"Tarefa"},
        {key:"setup", label:"Setup/Ambiente"},
        {key:"subtarefas", label:"Subtarefas"},
        {key:"preferencias", label:"Preferências"},
        {key:"observacoes", label:"Observações"}
      ],
      build: (v) => [
        `SSA, resuma o propósito do bloco em 1 frase e derive 3 micro-metas não negociáveis. Base: ‹${v.tarefa||""}›.`,
        `SSA, defina protocolo Central “entrar em foco”: ambiente, notificações, lista de corte e tempo total. Base: ‹${v.setup||""}›.`,
        `SSA, checklist Potência com timers (25/5) para as 3 micro-metas e checkpoint de meio do bloco. Base: ‹${v.subtarefas||""}›.`,
        `SSA, microtreino Box de 5–8 min (respiração + mobilidade) para antes/depois. Base: ‹${v.preferencias||""}›.`,
        `SSA, mini-retro (EOB): feito, atrito, uma melhoria. Base: ‹${v.observacoes||""}›.`
      ]
    },
    {
      id: "G",
      nome: "G) Energia & Antifragilidade (Box + Refúgio)",
      fields: [
        {key:"condicao", label:"Condição do dia"},
        {key:"ambiente", label:"Ambiente"},
        {key:"rotina", label:"Rotina"},
        {key:"top3", label:"Top‑3 do dia"}
      ],
      build: (v) => [
        `SSA, avalie energia (0–5) e proponha 2 microtreinos Box (≤10 min): um de ativação e um de recuperação. Base: ‹${v.condicao||""}›.`,
        `SSA, crie Elo do Refúgio (3–5 min) com passos claros e gatilho contextual. Base: ‹${v.ambiente||""}›.`,
        `SSA, defina “zona segura” Central para pausas: duração, frequência e regras de retorno ao foco. Base: ‹${v.rotina||""}›.`,
        `SSA, checklist Potência para integrar treino/pausas sem quebrar o T2 do dia. Base: ‹${v.top3||""}›.`
      ]
    },
    {
      id: "H",
      nome: "H) Limites & Comunhão (Central)",
      fields: [
        {key:"ruidos", label:"Fontes de ruído"},
        {key:"relacionamentos", label:"Relacionamentos/Contexto"},
        {key:"time", label:"Time/Projeto"}
      ],
      build: (v) => [
        `SSA, mapeie ruídos e distrações e formule 5 avisos prontos de “limitar exposição” para diferentes contextos (reunião, chat, e-mail, família, social). Base: ‹${v.ruidos||""}›.`,
        `SSA, desenhe um protocolo de “contexto neutro”: como pedir/ativar e quando encerrar. Base: ‹${v.relacionamentos||""}›.`,
        `SSA, defina janelas de comunicação e escadas de decisão (quem decide o quê e quando). Base: ‹${v.time||""}›.`
      ]
    },
    {
      id: "I",
      nome: "I) Finanças & Resultado (Talentos)",
      fields: [
        {key:"negocio", label:"Negócio"},
        {key:"planilha", label:"Planilha simples"},
        {key:"regras", label:"Regras"}
      ],
      build: (v) => [
        `SSA, derive 3 indicadores simples de resultado (receita, margem, tickets/semana) e metas de curto prazo. Base: ‹${v.negocio||""}›.`,
        `SSA, crie checklist Potência (5–7) para registro financeiro básico diário (entradas/saídas/observações). Base: ‹${v.planilha||""}›.`,
        `SSA, defina travas Central: tetos de gasto, aprovações e janela de revisão semanal. Base: ‹${v.regras||""}›.`
      ]
    },
    {
      id: "J",
      nome: "J) Crise/Incêndio (modo “corte seguro”)",
      fields: [
        {key:"situacao", label:"Situação"},
        {key:"agenda", label:"Agenda"},
        {key:"recursos", label:"Recursos"},
        {key:"stakeholders", label:"Stakeholders"},
        {key:"aprendizados", label:"Aprendizados"}
      ],
      build: (v) => [
        `SSA, sintetize o problema em 1 frase e 3 consequências se nada for feito. Base: ‹${v.situacao||""}›.`,
        `SSA, gere um “corte seguro” (Central): o que pausar/adiar e por quanto tempo. Base: ‹${v.agenda||""}›.`,
        `SSA, Sprint10 emergencial: 10 passos curtos para estabilizar em 90–120 min, com timers e pontos de não-retorno. Base: ‹${v.recursos||""}›.`,
        `SSA, plano de comunicação (Ide) em 3 bullets para partes interessadas (sem dados sensíveis). Base: ‹${v.stakeholders||""}›.`,
        `SSA, lições rápidas (3 bullets) e critério para encerrar o modo crise. Base: ‹${v.aprendizados||""}›.`
      ]
    },
    {
      id: "K",
      nome: "K) Revisão Diária & Arquivação",
      fields: [
        {key:"log", label:"Log do dia"},
        {key:"prioridades", label:"Prioridades de amanhã"},
        {key:"preferencias", label:"Preferências (template)"}
      ],
      build: (v) => [
        `SSA, faça uma revisão em 6 bullets: feito/pendente/atrito/aprendizados/agradecer/próximo foco. Base: ‹${v.log||""}›.`,
        `SSA, gere meu Top-3 neutro de amanhã: T1 Propósito (Chama), T2 Resultado (Talentos/Potência), T3 Elo do dia (calendário). Base: ‹${v.prioridades||""}›.`,
        `SSA, crie um template de “Registros” (anotações fáceis) com campos: data, foco, decisões, riscos, métrica 0–5 e anexos. Base: ‹${v.preferencias||""}›.`
      ]
    },
    {
      id: "L",
      nome: "L) Biblioteca de Mensagens (Ide) — uso responsável",
      fields: [
        {key:"perfil", label:"Perfil do contato"},
        {key:"funil", label:"Funil"}
      ],
      build: (v) => [
        `SSA, gere 4 roteiros Ide sem dados sensíveis: (1) pedido de contexto, (2) convite para chamada de 15 min, (3) agradecimento + próximo passo, (4) follow-up curto pós-reunião; todos com 1 CTA claro. Base: ‹${v.perfil||""}›.`,
        `SSA, checklist Potência para enviar e registrar respostas em até 30 min/dia, com timers e limites (Central). Base: ‹${v.funil||""}›.`
      ]
    },
    {
      id: "M",
      nome: "M) Aprendizado Contínuo (log leve)",
      fields: [
        {key:"tema", label:"Tema"},
        {key:"hipoteses", label:"Hipóteses"},
        {key:"calendario", label:"Calendário"}
      ],
      build: (v) => [
        `SSA, crie um “Diário de Aprendizado” com campos: insight, onde usei, próximo experimento, escore 0–5. Base: ‹${v.tema||""}›.`,
        `SSA, Sprint10 de experimentos (10 micro-testes) com estimativas rápidas e critério de descarte. Base: ‹${v.hipoteses||""}›.`,
        `SSA, protocolo Central para encerrar experimentos e proteger blocos de entrega. Base: ‹${v.calendario||""}›.`
      ]
    },
    {
      id: "N",
      nome: "N) Top‑3 Neutro (rápido, para o dia)",
      fields: [
        {key:"agenda", label:"Agenda + prioridades"},
        {key:"tarefas", label:"Tarefas (T2)"},
        {key:"rotina", label:"Rotina/energia"}
      ],
      build: (v) => [
        `SSA, gere meu Top-3 neutro: T1 Propósito (Chama), T2 Resultado (Talentos/Potência), T3 Elo do dia (calendário). Base: ‹${v.agenda||""}›.`,
        `SSA, formate checklist Potência para o T2 com timers (25/5) e Sprint10 final de revisão. Base: ‹${v.tarefas||""}›.`,
        `SSA, defina uma janela Refúgio (15–20 min) e 1 microtreino Box (≤10 min) para sustentar energia. Base: ‹${v.rotina||""}›.`
      ]
    }
  ];

  // Defaults neutros/seguros para cada trilha
  const DEFAULTS = {
    A: { agenda:"Dia padrão (neutro, sem sensíveis).", prioridades:"Objetivo claro; entrega mínima; compromisso no calendário.",
         ruidos:"Evitar distrações e mídias.", tarefas_criticas:"Fechar rascunho principal.", preferencias:"Respiração + alongamento breve.",
         ambiente:"Local silencioso e organizado.", escopo:"Fechar entrega principal do dia.", log:"Notas breves do dia.",
         resultados:"Resultados visíveis do dia." },
    B: { briefing:"Briefing genérico.", escopo:"Escopo mínimo viável.", pipeline:"Etapas simples do pipeline.",
         stakeholders:"Canais e responsáveis.", preferencias:"Aquecimento breve.", parcerias:"Contatos típicos (neutro).",
         agenda:"Pausas curtas distribuídas.", entrega_alvo:"Primeiro envio até D1." },
    C: { metas:"3 resultados chave.", calendario:"Blocos focais + revisão.", rotina:"Regras para foco.",
         tipo_trabalho:"Critérios de qualidade neutros.", preferencias:"Treinos rápidos.",
         leads:"Leads sem dados sensíveis.", energia:"Horários de descanso.", backlog:"Backlog simplificado.",
         registros:"Registros mínimos." },
    D: { produto:"Proposta de valor genérica.", perfil:"Perfil de contato típico.",
         meta_contatos:"Meta conservadora.", etica:"Limites de abordagem.", janela:"Janela diária curta." },
    E: { entrega:"Definição clara do que é 'pronto'.", workflow:"Rascunho→Revisão→Empacote→Envio.",
         prazos:"Limite de revisões.", escopo:"Fechar hoje." },
    F: { tarefa:"Bloco único bem definido.", setup:"Ambiente silencioso.", subtarefas:"3 micro‑metas.",
         preferencias:"Respiração + mobilidade.", observacoes:"Notas breves." },
    G: { condicao:"Energia moderada.", ambiente:"Gatilho simples p/ pausa.", rotina:"Pausas curtas sem quebrar foco.",
         top3:"Top‑3 do dia (neutro)." },
    H: { ruidos:"Notificações, interrupções, mídias.", relacionamentos:"Solicitar contexto neutro.", time:"Escada de decisão simples." },
    I: { negocio:"Indicadores básicos.", planilha:"Registros simples.", regras:"Tetos e aprovações." },
    J: { situacao:"Problema objetivo.", agenda:"Pausar itens não críticos.", recursos:"Recursos disponíveis.",
         stakeholders:"Comunicação objetiva.", aprendizados:"Lições breves." },
    K: { log:"Resumo do dia.", prioridades:"Topo de amanhã.", preferencias:"Campos simples de registro." },
    L: { perfil:"Contato genérico (neutro).", funil:"Limites e tempos curtos." },
    M: { tema:"Assunto de estudo.", hipoteses:"3 hipóteses pequenas.", calendario:"Janela de experimentos." },
    N: { agenda:"Agenda e prioridades do dia.", tarefas:"Checklist objetivo.", rotina:"Pausa e microtreino." }
  };

  // ------------ Estado ------------
  const state = {
    trilha: "A",
    values: {},
    generated: "",
    settings: {
      mode: "auto",            // auto | manual
      strategy: "both",        // enter | click | both
      delay: 2,                // s
      jitterMin: 0,            // s
      jitterMax: 0,            // s
      waitMode: "timeOnly",    // timeOnly | detectStream
      maxWait: 120,            // s
      retries: 1               // 0..5
    }
  };

  // Persistência simples
  const LS_KEY = "forjaelo_state_v2";
  function loadState() {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) {
        const saved = JSON.parse(raw);
        // merge básico
        Object.assign(state, saved);
        state.settings = Object.assign({}, state.settings, saved.settings||{});
      }
    } catch(_) {}
  }
  function saveState() {
    try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch(_) {}
  }

  // --------- Geração de filas ---------
  function getTrilha(id) { return TRILHAS.find(t => t.id === id); }

  function buildFromFields(id, values) {
    const t = getTrilha(id);
    if (!t) return [];
    return t.build(values||{});
  }

  // "Gerar Tudo (A–N)"
  function buildAllDefaults() {
    const prompts = [];
    for (const t of TRILHAS) {
      const vals = DEFAULTS[t.id] || {};
      prompts.push(...t.build(vals));
    }
    return prompts;
  }

  // --------- UI dinâmica ---------
  function renderTrilhaSelect() {
    const sel = $("#trilha");
    sel.innerHTML = TRILHAS.map(t => `<option value="${t.id}">${t.nome}</option>`).join("");
    sel.value = state.trilha || "A";
  }

  function renderFields() {
    const wrap = $("#trilhaFields");
    const t = getTrilha(state.trilha);
    if (!t) { wrap.innerHTML = "<p class='muted'>Trilha inválida.</p>"; return; }
    const vals = state.values[state.trilha] || {};
    wrap.innerHTML = t.fields.map(f => `
      <label for="f_${f.key}">${f.label}</label>
      <textarea id="f_${f.key}" data-key="${f.key}" placeholder="Opcional — usado em 'Base:'"></textarea>
    `).join("");
    // set values
    t.fields.forEach(f => {
      const el = $(`#f_${f.key}`);
      el.value = (vals && vals[f.key]) || "";
      el.addEventListener("input", () => {
        state.values[state.trilha] = state.values[state.trilha] || {};
        state.values[state.trilha][f.key] = el.value;
        saveState();
      });
    });
  }

  function setQueue(prompts) {
    const area = $("#bulkQueueInput");
    area.value = prompts.join("\n");
    updateCount();
    state.generated = area.value;
    saveState();
  }

  function parseQueueArea() {
    const raw = $("#bulkQueueInput").value || "";
    if (!raw.trim()) return [];
    // aceita ~ ou linhas
    let parts = [];
    if (raw.includes("~")) parts = raw.split("~");
    else parts = raw.split(/\r?\n/);
    // normalizar
    parts = parts.map(x => x.trim()).filter(Boolean);
    return parts;
  }

  function updateCount() {
    const count = parseQueueArea().length;
    $("#count").textContent = count;
    $("#pillCount") && ($("#pillCount").textContent = count);
  }

  // --------- Clipboard ---------
  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch(_) {
      // fallback
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
      return true;
    }
  }

  // --------- Envio para background ---------
  async function enqueue(prompts, settings) {
    return await chrome.runtime.sendMessage({ type:"enqueue", prompts, settings });
  }
  async function control(action) {
    return await chrome.runtime.sendMessage({ type:"control", action });
  }

  // --------- Inicialização ---------
  function initUI() {
    // Restaura queue
    $("#bulkQueueInput").value = state.generated || "";
    updateCount();

    // Trilha + campos
    renderTrilhaSelect();
    renderFields();
    $("#trilha").addEventListener("change", () => {
      state.trilha = $("#trilha").value;
      saveState();
      renderFields();
    });

    // Botões da seção "Trilhas"
    $("#generateQueue").addEventListener("click", () => {
      const prompts = buildFromFields(state.trilha, state.values[state.trilha]||{});
      setQueue(prompts);
      $("#status").textContent = `Gerado: ${prompts.length} prompts.`;
      setTimeout(() => $("#status").textContent = "", 2000);
    });

    $("#copyGenerated").addEventListener("click", async () => {
      await copyText($("#bulkQueueInput").value);
      $("#status").textContent = "Copiado ✅";
      setTimeout(() => $("#status").textContent = "", 1400);
    });

    // Seção "Fila"
    $("#bulkQueueInput").addEventListener("input", () => { updateCount(); saveState(); });

    $("#btnDedup").addEventListener("click", () => {
      const list = parseQueueArea();
      const seen = new Set();
      const dedup = list.filter(x => {
        const k = x.toLowerCase().trim();
        if (seen.has(k)) return false;
        seen.add(k); return true;
      });
      setQueue(dedup);
    });

    $("#btnShuffle").addEventListener("click", () => {
      const list = parseQueueArea();
      for (let i=list.length-1;i>0;i--) {
        const j = Math.floor(Math.random()*(i+1));
        [list[i], list[j]] = [list[j], list[i]];
      }
      setQueue(list);
    });

    $("#btnSplitTilde").addEventListener("click", () => {
      const raw = $("#bulkQueueInput").value;
      const arr = raw.split("~").map(s => s.trim()).filter(Boolean);
      setQueue(arr);
    });
    $("#btnSplitLines").addEventListener("click", () => {
      const raw = $("#bulkQueueInput").value;
      const arr = raw.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
      setQueue(arr);
    });

    // Import/Export
    $("#importFile").addEventListener("change", async (ev) => {
      const f = ev.target.files && ev.target.files[0];
      if (!f) return;
      const text = await f.text();
      // aceita ~ e/ou linhas
      const parts = (text.includes("~") ? text.split("~") : text.split(/\r?\n/)).map(s => s.trim()).filter(Boolean);
      setQueue(parts);
      ev.target.value = "";
    });
    $("#exportQueue").addEventListener("click", () => {
      const data = parseQueueArea().join("\n");
      const blob = new Blob([data], {type:"text/plain;charset=utf-8"});
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "fila-forjaelo.txt";
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
      a.remove();
    });
    $("#clearButton").addEventListener("click", () => {
      setQueue([]);
    });

    // Atrasos & Modos
    const setNum = (id, key) => {
      const el = $(id);
      if (!el) return;
      el.value = state.settings[key];
      el.addEventListener("input", () => {
        state.settings[key] = Number(el.value||0);
        saveState();
      });
    };
    const setSel = (id, key) => {
      const el = $(id);
      if (!el) return;
      el.value = state.settings[key];
      el.addEventListener("change", () => {
        state.settings[key] = el.value;
        saveState();
      });
    };

    setNum("#promptDelay", "delay");
    setNum("#promptDelayMin", "jitterMin");
    setNum("#promptDelayMax", "jitterMax");
    setNum("#maxWait", "maxWait");
    setNum("#retries", "retries");
    setSel("#sendMode", "mode");
    setSel("#sendStrategy", "strategy");
    setSel("#waitMode", "waitMode");

    // Enfileirar / Copiar / Controles
    async function doEnfileirar(prompts) {
      const list = prompts || parseQueueArea();
      if (!list.length) {
        $("#miniStatus").textContent = "fila vazia";
        return;
      }
      if (state.settings.mode === "manual") {
        await copyText(list.join("\n"));
        $("#miniStatus").textContent = `copiado (${list.length})`;
        setTimeout(() => $("#miniStatus").textContent = "pronto", 1500);
        return;
      }
      // Enviar para background → content.js
      const settings = {
        delay: state.settings.delay,
        jitterMin: state.settings.jitterMin,
        jitterMax: state.settings.jitterMax,
        strategy: state.settings.strategy,
        waitMode: state.settings.waitMode,
        maxWait: state.settings.maxWait,
        retries: state.settings.retries
      };
      $("#miniStatus").textContent = "enfileirando…";
      try {
        await enqueue(list, settings);
        $("#miniStatus").textContent = `enfileirado (${list.length})`;
      } catch (e) {
        $("#miniStatus").textContent = "erro ao enfileirar";
        console.error(e);
      }
      setTimeout(() => $("#miniStatus").textContent = "pronto", 1800);
    }

    $("#queueButton").addEventListener("click", () => doEnfileirar());
    $("#copyButton").addEventListener("click", async () => {
      await copyText(parseQueueArea().join("\n"));
      $("#miniStatus").textContent = "copiado";
      setTimeout(() => $("#miniStatus").textContent = "pronto", 1200);
    });

    $("#pauseQueue").addEventListener("click", async () => { await control("pause"); $("#miniStatus").textContent = "pausado"; });
    $("#resumeQueue").addEventListener("click", async () => { await control("resume"); $("#miniStatus").textContent = "retomado"; setTimeout(()=>$("#miniStatus").textContent="pronto",1000); });
    $("#cancelQueue").addEventListener("click", async () => { await control("cancel"); $("#miniStatus").textContent = "cancelado"; setTimeout(()=>$("#miniStatus").textContent="pronto",1000); });

    // Aplicar Agora (sem preencher)
    const cenarioSel = $("#cenarioDireto");
    const options = [
      {value:"A", label:"A) Dia Completo"},
      {value:"B", label:"B) Projeto (kickoff → D1)"},
      {value:"C", label:"C) Semana Completa"},
      {value:"D", label:"D) Funil de Parcerias"},
      {value:"E", label:"E) Qualidade & Excelência"},
      {value:"F", label:"F) Foco Profundo"},
      {value:"G", label:"G) Energia & Antifragilidade"},
      {value:"H", label:"H) Limites & Comunhão"},
      {value:"I", label:"I) Finanças & Resultado"},
      {value:"J", label:"J) Crise/Incêndio"},
      {value:"K", label:"K) Revisão Diária & Arquivação"},
      {value:"L", label:"L) Biblioteca de Mensagens"},
      {value:"M", label:"M) Aprendizado Contínuo"},
      {value:"N", label:"N) Top‑3 Neutro"},
      {value:"ALL", label:"Gerar Tudo (A–N) — uma única fila"}
    ];
    cenarioSel.innerHTML = options.map(o => `<option value="${o.value}">${o.label}</option>`).join("");
    cenarioSel.value = "ALL";

    $("#btnGerarDefaults").addEventListener("click", () => {
      const val = cenarioSel.value;
      let prompts = [];
      if (val === "ALL") prompts = buildAllDefaults();
      else prompts = buildFromFields(val, DEFAULTS[val]||{});
      setQueue(prompts);
      $("#miniStatus").textContent = `gerado (${prompts.length})`;
      setTimeout(() => $("#miniStatus").textContent = "pronto", 1500);
    });

    $("#btnEnfileirarDefaults").addEventListener("click", async () => {
      const val = cenarioSel.value;
      let prompts = [];
      if (val === "ALL") prompts = buildAllDefaults();
      else prompts = buildFromFields(val, DEFAULTS[val]||{});
      await doEnfileirar(prompts);
    });

    // Presets rápidos (opcionais se presentes no HTML)
    const presetSemana = $("#presetSemana");
    const presetDia = $("#presetDia");
    const presetProjeto = $("#presetProjeto");
    if (presetDia) presetDia.addEventListener("click", () => {
      state.trilha = "A";
      const sel = $("#trilha"); if (sel) sel.value = "A";
      setQueue(buildFromFields("A", DEFAULTS["A"]));
      renderFields();
      $("#status").textContent = "Dia (defaults) gerados";
      setTimeout(()=>$("#status").textContent="",1200);
    });
    if (presetProjeto) presetProjeto.addEventListener("click", () => {
      state.trilha = "B";
      const sel = $("#trilha"); if (sel) sel.value = "B";
      setQueue(buildFromFields("B", DEFAULTS["B"]));
      renderFields();
      $("#status").textContent = "Projeto (defaults) gerados";
      setTimeout(()=>$("#status").textContent="",1200);
    });

    const presetCrise  = $("#presetCrise");
    if (presetSemana) presetSemana.addEventListener("click", () => {
      state.trilha = "C"; const sel = $("#trilha"); if (sel) sel.value = "C";
      setQueue(buildFromFields("C", DEFAULTS["C"])); renderFields();
      $("#status").textContent = "Semana (defaults) gerados";
      setTimeout(()=>$("#status").textContent="",1200);
    });
    if (presetCrise) presetCrise.addEventListener("click", () => {
      state.trilha = "J"; const sel = $("#trilha"); if (sel) sel.value = "J";
      setQueue(buildFromFields("J", DEFAULTS["J"])); renderFields();
      $("#status").textContent = "Crise (defaults) gerados";
      setTimeout(()=>$("#status").textContent="",1200);
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    loadState();
    initUI();
  });
})();
